// ============================================================
// EASY EDIT AREA
// 1. Replace the photos in /images/
// 2. Edit the captions in index.html
// 3. Put your music at /music/music.mp3
// 4. Edit the love letter and memories in index.html
// ============================================================

const opening = document.getElementById("opening");
const mainContent = document.getElementById("mainContent");
const openHeart = document.getElementById("openHeart");
const typingText = document.getElementById("typingText");
const bgMusic = document.getElementById("bgMusic");
const musicBtn = document.getElementById("musicBtn");
const floatingHearts = document.getElementById("floatingHearts");
const petals = document.getElementById("petals");

const introMessage =
  "You are one of the most beautiful parts of my life. Thank you for being there, for making me smile, and for creating so many beautiful memories with me.";

openHeart.addEventListener("click", () => {
  opening.style.transition = "opacity .7s ease, transform .7s ease";
  opening.style.opacity = "0";
  opening.style.transform = "scale(1.03)";

  setTimeout(() => {
    opening.classList.add("hidden");
    mainContent.classList.remove("hidden");
    document.body.style.overflowX = "hidden";
    typeText(introMessage);
    createBackgroundEffects();
    observeReveals();
  }, 650);
});

function typeText(text) {
  let i = 0;
  typingText.textContent = "";

  const timer = setInterval(() => {
    typingText.textContent += text[i];
    i++;

    if (i >= text.length) {
      clearInterval(timer);
    }
  }, 22);
}

// Music: browsers usually block autoplay, so it starts only after a tap.
musicBtn.addEventListener("click", async () => {
  if (bgMusic.paused) {
    try {
      await bgMusic.play();
      musicBtn.innerHTML = "❚❚ <span>Pause our song</span>";
    } catch (error) {
      musicBtn.innerHTML = "♫ <span>Add music.mp3 first</span>";
    }
  } else {
    bgMusic.pause();
    musicBtn.innerHTML = "♫ <span>Play our song</span>";
  }
});

// Photo lightbox
const lightbox = document.getElementById("lightbox");
const lightboxImage = document.getElementById("lightboxImage");
const closeLightbox = document.getElementById("closeLightbox");

document.querySelectorAll(".photo-card img").forEach(img => {
  img.addEventListener("click", () => {
    lightboxImage.src = img.src;
    lightboxImage.alt = img.alt;
    lightbox.classList.add("active");
    lightbox.setAttribute("aria-hidden", "false");
  });
});

function closeBox() {
  lightbox.classList.remove("active");
  lightbox.setAttribute("aria-hidden", "true");
}

closeLightbox.addEventListener("click", closeBox);
lightbox.addEventListener("click", e => {
  if (e.target === lightbox) closeBox();
});

document.addEventListener("keydown", e => {
  if (e.key === "Escape") closeBox();
});

// Hearts appear where the user taps/clicks.
document.addEventListener("pointerdown", e => {
  if (e.target.closest("button") || e.target.closest(".lightbox")) return;

  const heart = document.createElement("span");
  heart.className = "click-heart";
  heart.textContent = Math.random() > .5 ? "♥" : "♡";
  heart.style.left = `${e.clientX}px`;
  heart.style.top = `${e.clientY}px`;
  document.body.appendChild(heart);

  setTimeout(() => heart.remove(), 950);
});

function createBackgroundEffects() {
  // Keep this light for phones.
  for (let i = 0; i < 12; i++) {
    setTimeout(() => createHeart(), i * 500);
  }

  setInterval(createHeart, 1500);
  setInterval(createPetal, 2400);
}

function createHeart() {
  const heart = document.createElement("span");
  heart.className = "float-heart";
  heart.textContent = Math.random() > .35 ? "♥" : "♡";
  heart.style.left = `${Math.random() * 100}%`;
  heart.style.fontSize = `${10 + Math.random() * 13}px`;
  heart.style.animationDuration = `${5 + Math.random() * 4}s`;
  floatingHearts.appendChild(heart);

  setTimeout(() => heart.remove(), 9500);
}

function createPetal() {
  const petal = document.createElement("span");
  petal.className = "petal";
  petal.textContent = "✿";
  petal.style.left = `${Math.random() * 100}%`;
  petal.style.fontSize = `${9 + Math.random() * 10}px`;
  petal.style.animationDuration = `${6 + Math.random() * 5}s`;
  petals.appendChild(petal);

  setTimeout(() => petal.remove(), 12000);
}

// Scroll reveal
function observeReveals() {
  const elements = document.querySelectorAll(".reveal");

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("visible");
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12 });

  elements.forEach(el => observer.observe(el));
}
