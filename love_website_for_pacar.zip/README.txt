# 💗 Love Website

Website romantis mobile-responsive untuk dibuka dari HP.

## Struktur

- `index.html` = isi website dan teks yang bisa diedit
- `style.css` = tampilan dan animasi
- `script.js` = interaksi, typing, musik, hearts, lightbox
- `images/image1.jpg` = foto pertama
- `images/image2.jpg` = foto kedua
- `music/music.mp3` = tempat file musik

## Cara menjalankan

Cukup buka `index.html` di browser.

## Cara mengganti foto

Ganti file:
- `images/image1.jpg`
- `images/image2.jpg`

Atau ubah nama file di bagian `<img src="...">` pada `index.html`.

## Cara mengganti musik

Masukkan file musik MP3 bernama:

`music/music.mp3`

Browser biasanya tidak mengizinkan musik autoplay. Musik dimulai setelah tombol "Play our song" ditekan.

## Cara mengganti tulisan

Semua pesan cinta, caption foto, dan timeline bisa diedit langsung di `index.html`.

## Cara menambah foto

Salin salah satu blok:

```html
<figure class="photo-card reveal">
  <img src="images/image3.jpg" alt="Memory">
  <figcaption>
    <strong>Your caption here.</strong>
    <span>Your short message here.</span>
  </figcaption>
</figure>
```

Lalu masukkan foto baru ke folder `images`.

## Catatan

Website dibuat tanpa framework agar mudah dipahami dan diedit pemula.
